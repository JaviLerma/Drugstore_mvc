# Drugstore_mvc

## TODO:

<br>-Verificar si existe una session activa
<br>-Resolver si usar español o ingles
<br>-Comprobar la cantidad de caracteres que recibe la db como maximo para q no haya error.
<br>-Manejar mejor los singulares y plurales
<br>-Mejorar la distribucion de archivos y carpetas (analizar si es necesario tenes subscarpetas con el mimso nombre del archivo?)
<br>-$this->session = new Session(); //verificar si es nesesario hacer esto en cada clase
<br>-Averiguar como reaalizar el header y nav var en un solo archivo dinamico
<br>-Falta realizar borrado y modificacion x TRANSACCION
<br>-Error donde se muestra la lista de clientes, usuarios, proveedores, etc cuando la tabla esta vacia
<br>-La funcion DELETEBYID, es la mejor, la mas facil de adaptar a otras tablas, tratar de hacer las demas asi
<br>


Se accede desde http://localhost/Drugstore_mvc/login
<br>
usuario: admin
<br>
contraseña : 1234